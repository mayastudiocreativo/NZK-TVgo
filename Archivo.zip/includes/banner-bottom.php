<?php
// banners.php → banners superior e inferior reutilizables
?>

<!-- Banner inferior -->
<section class="banner-slot banner-top">
  <div class="banner-placeholder banner-img-container">
    <img src="./img/bannerPublicidad.jpg" alt="Publicidad">
  </div>
</section>