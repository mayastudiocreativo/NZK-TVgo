<!-- includes/splash.php -->
<div id="app-splash" class="app-splash">
  <div class="app-splash-inner">
    <img
      src="./img/iconIOS/icon.png"
      alt="NZK tvGO"
      class="app-splash-logo"
    />
    <p class="app-splash-text">Cargando NZK tvGO…</p>
    <div class="app-splash-spinner"></div>
  </div>
</div>